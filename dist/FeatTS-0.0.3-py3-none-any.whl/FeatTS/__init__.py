#__init__.py

__version__ = "0.0.1"
__author__ = 'Donato Tiano'

from .featTS_core import FeatTS